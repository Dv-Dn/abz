These filters have been specifically adjusted to suit console gameplay better 
(because they can pick up masses of items faster and easier, but have a harder time picking out the right items).

Generally speaking they're higher strictness filters that show more currency:

Constrict1x:	Strict + All Currency (incl. scrolls)
Constrict2x:	Very  Strict + All Currency (incl. scrolls)
Constrict3x:	Very  Strict + All Currency (EXCL. Scrolls and armourers and trash divination cards)
Constrict4x:	Uber  Strict + All Currency (EXCL. Scrolls and armourers and trash divination cards)
Constrict5x:	Uber+ Strict + All Currency (EXCL. Scrolls and armourers and trash divination cards)

Additionally all these filters show fewer crafting bases, no chancing bases and don't completely hide "outleveled" low tier maps.

These filters can also be used by PC players, but players are better off going to www.filterblade.xyz and adjusting finetuning these filters to their liking.